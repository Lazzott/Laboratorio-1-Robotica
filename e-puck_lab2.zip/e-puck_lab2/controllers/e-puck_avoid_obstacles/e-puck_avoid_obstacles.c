#include <stdio.h>
#include <stdlib.h>

#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/keyboard.h>

#define MAX_SPEED 6.28
#define LEFT 0
#define RIGHT 1

static WbDeviceTag left_motor, right_motor;
static double speeds[2] = {0.5 * MAX_SPEED, 0.5 * MAX_SPEED};

static int get_time_step() {
  return (int)wb_robot_get_basic_time_step();
}

int main(int argc, char **argv) {
  wb_robot_init();

  int time_step = get_time_step();

  // Inicializar motores
  left_motor = wb_robot_get_device("left wheel motor");
  right_motor = wb_robot_get_device("right wheel motor");

  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);

  wb_motor_set_velocity(left_motor, speeds[LEFT]);
  wb_motor_set_velocity(right_motor, speeds[RIGHT]);

  // Activar teclado
  wb_keyboard_enable(time_step);

  printf("Control manual iniciado\n");
  printf("\n=== CONTROLES DEL ROBOT ===\n");
  printf("W : Avanzar\n");
  printf("S : Retroceder\n");
  printf("Q : Invertir motor izquierdo\n");
  printf("E : Invertir motor derecho\n");
  printf("A : Reducir velocidad motor izquierdo\n");
  printf("D : Reducir velocidad motor derecho\n");
  printf("===========================\n\n");

  while (wb_robot_step(time_step) != -1) {

    int key = wb_keyboard_get_key();

    // Movimiento base: línea recta
    speeds[LEFT] = 0.5 * MAX_SPEED;
    speeds[RIGHT] = 0.5 * MAX_SPEED;

    while (key != -1) {

      switch (key) {

        case 'W': // avanzar
          speeds[LEFT] = MAX_SPEED;
          speeds[RIGHT] = MAX_SPEED;
          break;

        case 'S': // retroceder
          speeds[LEFT] = -MAX_SPEED;
          speeds[RIGHT] = -MAX_SPEED;
          break;

        case 'Q': // invertir motor izquierdo
          speeds[LEFT] = -speeds[LEFT];
          break;

        case 'E': // invertir motor derecho
          speeds[RIGHT] = -speeds[RIGHT];
          break;

        case 'A': // reducir velocidad izquierda
          speeds[LEFT] *= 0.5;
          break;

        case 'D': // reducir velocidad derecha
          speeds[RIGHT] *= 0.5;
          break;
      }

      key = wb_keyboard_get_key();
    }

    // Aplicar velocidades
    wb_motor_set_velocity(left_motor, speeds[LEFT]);
    wb_motor_set_velocity(right_motor, speeds[RIGHT]);
  }

  wb_robot_cleanup();
  return 0;
}