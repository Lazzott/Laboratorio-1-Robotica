#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/distance_sensor.h>
#include <webots/position_sensor.h>

#define TIME_STEP 64

#define MAX_SPEED 6.28

#define LEFT 0
#define RIGHT 1

#define PS_RIGHT_FRONT 0
#define PS_LEFT_FRONT 7
#define PS_LEFT_SIDE 6
#define PS_RIGHT_SIDE 1

#define WHEEL_RADIUS 0.0205
#define AXLE_LENGTH 0.053

#define FRONT_THRESHOLD 350.0

#define FORWARD_SPEED 4.0
#define TURN_SPEED 2.5


#define ALPHA 0.85

#define Q 1.0
#define R 15.0

int main(int argc, char **argv) {

  wb_robot_init();

  WbDeviceTag motors[2];

  motors[LEFT] =
      wb_robot_get_device("left wheel motor");

  motors[RIGHT] =
      wb_robot_get_device("right wheel motor");

  wb_motor_set_position(motors[LEFT], INFINITY);
  wb_motor_set_position(motors[RIGHT], INFINITY);

  wb_motor_set_velocity(motors[LEFT], 0.0);
  wb_motor_set_velocity(motors[RIGHT], 0.0);

  WbDeviceTag left_encoder =
      wb_robot_get_device("left wheel sensor");

  WbDeviceTag right_encoder =
      wb_robot_get_device("right wheel sensor");

  wb_position_sensor_enable(left_encoder, TIME_STEP);
  wb_position_sensor_enable(right_encoder, TIME_STEP);

  WbDeviceTag ps[8];

  char sensor_name[5];

  for (int i = 0; i < 8; i++) {

    sprintf(sensor_name, "ps%d", i);

    ps[i] = wb_robot_get_device(sensor_name);

    wb_distance_sensor_enable(ps[i], TIME_STEP);
  }

  double prev_left_enc = 0.0;
  double prev_right_enc = 0.0;


  double filtered_front = 0.0;


  double estimated_distance = 0.0;

  double P = 1.0;


  FILE *log_file =
      fopen("sensor_log.csv", "w");

  fprintf(log_file,
          "time,"
          "front_raw,"
          "front_filtered,"
          "front_estimated,"
          "left_encoder,"
          "right_encoder\n");

  printf("=====================================\n");
  printf("CONTROLADOR AUTOMATICO INICIADO\n");
  printf("=====================================\n");


  while (wb_robot_step(TIME_STEP) != -1) {

    double front_left =
        wb_distance_sensor_get_value(ps[PS_LEFT_FRONT]);

    double front_right =
        wb_distance_sensor_get_value(ps[PS_RIGHT_FRONT]);

    double left_side =
        wb_distance_sensor_get_value(ps[PS_LEFT_SIDE]);

    double right_side =
        wb_distance_sensor_get_value(ps[PS_RIGHT_SIDE]);

    double front_raw =
        fmax(front_left, front_right);

    filtered_front =
        ALPHA * filtered_front +
        (1.0 - ALPHA) * front_raw;

    double left_enc =
        wb_position_sensor_get_value(left_encoder);

    double right_enc =
        wb_position_sensor_get_value(right_encoder);

    double delta_left =
        left_enc - prev_left_enc;

    double delta_right =
        right_enc - prev_right_enc;

    prev_left_enc = left_enc;
    prev_right_enc = right_enc;


    double dist_left =
        WHEEL_RADIUS * delta_left;

    double dist_right =
        WHEEL_RADIUS * delta_right;

    double robot_advance =
        (dist_left + dist_right) / 2.0;


    double predicted_distance =
        estimated_distance +
        robot_advance * 100.0;

    double P_pred = P + Q;

    double K =
        P_pred / (P_pred + R);

    estimated_distance =
        predicted_distance +
        K * (filtered_front - predicted_distance);

    P = (1.0 - K) * P_pred;

    double left_speed;
    double right_speed;

    if (estimated_distance < FRONT_THRESHOLD) {


      left_speed = FORWARD_SPEED;
      right_speed = FORWARD_SPEED;

    } else {


      if (left_side > right_side) {

        left_speed = TURN_SPEED;
        right_speed = -TURN_SPEED;

      } else {


        left_speed = -TURN_SPEED;
        right_speed = TURN_SPEED;
      }
    }

    wb_motor_set_velocity(
        motors[LEFT],
        left_speed);

    wb_motor_set_velocity(
        motors[RIGHT],
        right_speed);

    double time =
        wb_robot_get_time();

    fprintf(log_file,
            "%f,%f,%f,%f,%f,%f\n",
            time,
            front_raw,
            filtered_front,
            estimated_distance,
            left_enc,
            right_enc);

    printf("Raw: %.2f | EMA: %.2f | Kalman: %.2f\n",
           front_raw,
           filtered_front,
           estimated_distance);
  }

  fclose(log_file);

  wb_robot_cleanup();

  return 0;
}