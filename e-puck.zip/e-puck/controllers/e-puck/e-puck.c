#include <stdio.h>
#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/keyboard.h>

#define TIME_STEP 64
#define MAX_SPEED 6.28

int main() {
  wb_robot_init();

  WbDeviceTag left_motor = wb_robot_get_device("left wheel motor");
  WbDeviceTag right_motor = wb_robot_get_device("right wheel motor");

  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);

  wb_keyboard_enable(TIME_STEP);

  int left_half_mode = 0;
  int right_half_mode = 0;

  // 🔑 Estados persistentes
  int left_forward = 0, left_backward = 0;
  int right_forward = 0, right_backward = 0;

  // 🔑 Para evitar múltiples toggles
  int q_pressed = 0;
  int p_pressed = 0;

  printf("=== CONTROL INDEPENDIENTE ===\n");
  printf("W/S Rueda izquierda\n");
  printf("O/L Rueda derecha\n");
  printf("Q cambio de velocidad rueda izquierda\n");
  printf("P cambio de velocidad rueda derecha\n");

  while (wb_robot_step(TIME_STEP) != -1) {

    int key;

    // Reset estados (se reconstruyen cada frame)
    left_forward = left_backward = 0;
    right_forward = right_backward = 0;

    int q_detected = 0;
    int p_detected = 0;

    while ((key = wb_keyboard_get_key()) != -1) {

      // Movimiento
      if (key == 'W') left_forward = 1;
      if (key == 'S') left_backward = 1;
      if (key == 'O') right_forward = 1;
      if (key == 'L') right_backward = 1;

      // Detectar pulsación única (anti-rebote)
      if (key == 'Q') q_detected = 1;
      if (key == 'P') p_detected = 1;
    }

    // Toggle SOLO cuando se presiona (no mantener)
    if (q_detected && !q_pressed) {
      left_half_mode = !left_half_mode;
      printf("Izquierda: %s\n", left_half_mode ? "REDUCIDA" : "NORMAL");
    }

    if (p_detected && !p_pressed) {
      right_half_mode = !right_half_mode;
      printf("Derecha: %s\n", right_half_mode ? "REDUCIDA" : "NORMAL");
    }

    q_pressed = q_detected;
    p_pressed = p_detected;

    double left_speed = 0.0;
    double right_speed = 0.0;

    // Movimiento base
    if (left_forward)
      left_speed = MAX_SPEED;
    else if (left_backward)
      left_speed = -MAX_SPEED;

    if (right_forward)
      right_speed = MAX_SPEED;
    else if (right_backward)
      right_speed = -MAX_SPEED;

    // Aplicar modo reducido
    if (left_half_mode)
      left_speed *= 0.5;

    if (right_half_mode)
      right_speed *= 0.5;

    wb_motor_set_velocity(left_motor, left_speed);
    wb_motor_set_velocity(right_motor, right_speed);
  }

  wb_robot_cleanup();
  return 0;
}